---
layout: post
title: "Your Daily Update"
date: {{ site.time | date: "%Y-%m-%d %H:%M:%S" }}
---
This is your daily blog entry content.
