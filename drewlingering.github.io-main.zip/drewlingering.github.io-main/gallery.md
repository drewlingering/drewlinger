---
layout: default
title: "Image Gallery"
---

# Image Gallery

<div class="gallery">
    <div class="gallery-item">
        <img src="/assets/images/GMM8ePeWsAAL859.jpg" alt="Image 1">
        <p>Image 1 Manned aerial rotorcraft sketching idea</p>
    </div>
    <div class="gallery-item">
        <img src="/assets/images/GMM1d6sWUAAZbBc.jpg" alt="Image 2">
        <p>Image 2 Five stage to orbit idea sketch - sled | efan | scram | lenticular rocket | abep |</p>
    </div>
    <div class="gallery-item">
        <img src="/assets/images/GPTEiMeWoAAsIBI.jpg" alt="Image 3">
        <p>Image 3 towt idea sketch; i.e. wind propulsion</p>
    </div>
    <div class="gallery-item">
        <img src="/assets/images/bafkreicrnevb4aazvtkt5gk4cozvftypeyok7muwswcyis3kkee3emrjda2.jpg" alt="Image 4">
        <p>Image 4 mhd fuel cell hybrid vehicle idea sketch; i.e. wind propulsion</p>
    </div>
    <div class="gallery-item">
        <img src="/assets/images/Screenshot_30-6-2025_123340.jpeg" alt="Image 5">
        <p>Source: @domainofscience youtube.com</p>
    </div>
    <!-- Add more images as needed -->
</div>
